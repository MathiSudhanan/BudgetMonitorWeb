﻿namespace BudgetMonitor.Entities
{
    public class ChangePasswordDTO
    {
        public int UserId { get; set; }
        public string NewPassword { get; set; }
    }
}
