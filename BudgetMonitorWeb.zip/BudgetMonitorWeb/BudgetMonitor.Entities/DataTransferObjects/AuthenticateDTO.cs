﻿namespace BudgetMonitor.Entities
{
    public class AuthenticateDTO
    {
        public string EmailId { get; set; }
        public string Password { get; set; }
    }
}
