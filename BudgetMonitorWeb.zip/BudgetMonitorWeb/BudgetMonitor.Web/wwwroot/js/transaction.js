﻿var dataTable;
$(document).ready(function () {
    loadDataTable();
});

function loadDataTable() {
    //dataTable = $('#tblUsers').DataTable();

    dataTable = $('#tblTransactions').DataTable({
        "ajax": {
            "url": "/Transaction/GetAllTransactions",
            "type": "GET",
            "datatype": "json"
        },
        "columns": [
            {
                "data": "transactionDate",
                "render": function (data) {
                    return `<td align="center">${data.substring(0, 10)}</td>`;

                },
                "width": "20%"
            },
            {
                "data": "name", "width": "30%"
            },
            {
                "data": "amount",
                "render": function (data) {
                    if(data>0)
                        return `<td align="right">Rs ${data}</td>`;
                    else
                        return `<td></td>`;
                },
                "width": "15%"
            },
            {
                "data": "amount",
                "render": function (data) {
                    if (data < 0)
                        return `<td align="right">Rs ${data}</td>`;
                    else
                        return `<td></td>`;
                },
                "width": "15%"
            },
            {
                "data": "id",
                "render": function (data) {
                    return `<div class="text-center">
                                <a href="/Transaction/Upsert/${data}" class="btn btn-success text-white">
                                    <i class="far fa-edit"></i>
                                </a>&nbsp;
                                <a onclick=Delete("/Transaction/Delete/${data}") class="btn btn-danger text-white">
                                    <i class="far fa-trash-alt"></i>
                                </a>&nbsp;
                            </div >`;
                },
                "width": "20%"
            }
        ]
    });
}

function Delete(url) {
    swal({
        title: "Are you sure you want to Delete?",
        text: "You will not be able to restore the data!",
        icon: "warning",
        buttons: true,
        dangerMode: true
    }).then((willDelete) => {
        if (willDelete) {
            $.ajax({
                type: 'DELETE',
                url: url,
                success: function (data) {
                    if (data.success) {
                        toastr.success(data.message);
                        dataTable.ajax.reload();
                    }
                    else {
                        toastr.error(data.message);
                    }
                }
            });
        }
    });

}