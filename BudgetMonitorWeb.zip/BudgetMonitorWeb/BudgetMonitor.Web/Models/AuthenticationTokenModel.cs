﻿namespace BudgetMonitor.Web.Models
{
    public class AuthenticationTokenModel
    {
        public string UserName { get; set; }

        public string Token { get; set; }
    }
}
