﻿namespace BudgetMonitor.Business
{
    public class AppSettings
    {
        public string Secret { get; set; }
    }
}
