﻿using BudgetMonitor.DAL;
namespace BudgetMonitor.Business
{
    public class BaseBusiness 
    {
        protected UnitOfWork UnitOfWork = new UnitOfWork();
        
    }
}
