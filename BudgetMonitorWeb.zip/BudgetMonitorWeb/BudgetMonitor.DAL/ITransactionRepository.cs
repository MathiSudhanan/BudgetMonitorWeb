﻿using BudgetMonitor.Entities;

namespace BudgetMonitor.DAL
{
    public interface ITransactionRepository : IGenericRepository<TransactionEntity>
    {
    }
}
